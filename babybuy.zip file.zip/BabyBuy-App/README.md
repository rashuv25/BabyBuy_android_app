<h1>Baby Buy</h1>
<p>An Android Application aimed for mothers as a noting application where they can list the items they want to buy.</p>
<h3>Features</h3>
<ul>
  <li>Supports Multi User.</li>
  <li>Username and Password</li>
  <li>Google Map Tagging, Sharing and saving.</li>
  <li>Beautiful and cool design.</li>
</ul>

<h1>ScreenShots</h1>
<img width="100%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/88843bef-c22a-4fa9-a906-0a2025652d99">
<div style="display:flex; width:100%">  
<img width="20%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/36a1f496-9f52-4d46-968b-de59803143f7">
<img width="20%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/ce3b7ab7-9662-483e-a512-6e52d2cd0cee">
<img width="20%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/299f956c-42ab-4c55-b1fb-0fffc2c5e05a">
<img width="20%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/79efbaae-e681-48d8-b166-ed923f430ed3">
<img width="20%" alt="image" src="https://github.com/dineshdahal/BabyBuy/assets/86043915/033dcedc-691f-46db-a458-563c596bc71f">

</div>

