package com.rupeshyadav.babybuy.Model;

public class CatDataModel {
    public int catid;
    public String catname;

    public int getCatid() {
        return catid;
    }

    public void setCatid(int catid) {
        this.catid = catid;
    }

    public String getCatname() {
        return catname;
    }

    public void setCatname(String catname) {
        this.catname = catname;
    }
}
